package com.example.rgbkeyboard

import android.graphics.Color
import kotlin.math.PI
import kotlin.math.sin

class RgbTheme(val name: String, val h1: Float, val h2: Float, val full: Boolean = false) {
    fun hue(base: Float, index: Int): Float {
        val a = base + index * 10f
        return if (full) a % 360f
        else h1 + (h2 - h1) * (0.5f + 0.5f * sin(a * PI.toFloat() / 180f))
    }
}

object Themes {
    val all = listOf(
        RgbTheme("Rainbow", 0f, 360f, true),
        RgbTheme("Ocean", 170f, 260f),
        RgbTheme("Fire", 0f, 55f),
        RgbTheme("Neon Pink", 280f, 340f),
        RgbTheme("Matrix", 95f, 150f)
    )

    fun color(h: Float, alpha: Int = 255): Int {
        val hh = ((h % 360f) + 360f) % 360f
        return Color.HSVToColor(alpha, floatArrayOf(hh, 1f, 1f))
    }
}
