package com.example.rgbkeyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("rgb", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(root)
        }

        fun label(t: String, size: Float = 16f, color: Int = Color.WHITE): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.textSize = size
            tv.setTextColor(color)
            tv.setPadding(0, pad, 0, pad / 2)
            return tv
        }

        root.addView(label("RGB Keyboard Premium", 26f, Color.CYAN))

        val b1 = Button(this)
        b1.text = "1. Keyboard ON karo"
        b1.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        root.addView(b1)

        val b2 = Button(this)
        b2.text = "2. Keyboard select karo"
        b2.setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        root.addView(b2)

        root.addView(label("Theme"))
        val group = RadioGroup(this)
        Themes.all.forEachIndexed { i, t ->
            val rb = RadioButton(this)
            rb.text = t.name
            rb.id = 100 + i
            rb.setTextColor(Color.WHITE)
            group.addView(rb)
        }
        group.check(100 + prefs.getInt("theme", 0).coerceIn(0, Themes.all.size - 1))
        group.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("theme", id - 100).apply()
        }
        root.addView(group)

        root.addView(label("Animation speed"))
        val seek = SeekBar(this)
        seek.max = 9
        seek.progress = prefs.getInt("speed", 5).coerceIn(1, 10) - 1
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.edit().putInt("speed", p + 1).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek)

        val sw = Switch(this)
        sw.text = "Key vibration"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = prefs.getBoolean("vibrate", true)
        sw.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("vibrate", c).apply() }
        root.addView(sw)

        root.addView(label("Test here"))
        val et = EditText(this)
        et.hint = "Yahan type kore dekho"
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(Color.GRAY)
        root.addView(et)

        setContentView(scroll)
    }
}
