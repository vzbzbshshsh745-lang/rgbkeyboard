package com.example.rgbkeyboard

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView

class RgbKeyboardService : InputMethodService() {

    private enum class Mode { LETTERS, SYMBOLS, EMOJI }
    private class Key(val view: TextView, val bg: GradientDrawable, val index: Int)

    private val keys = mutableListOf<Key>()
    private val letters = mutableListOf<TextView>()
    private var animator: ValueAnimator? = null
    private var shift = false
    private var mode = Mode.LETTERS
    private lateinit var container: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    private var theme = Themes.all[0]
    private var vibrate = true
    private var speed = 5

    private val emojis = listOf(
        "😀", "😂", "😍", "😎", "🥰", "😭", "😡", "🤔",
        "👍", "👎", "🙏", "👏", "🔥", "❤️", "💯", "🎉",
        "😊", "😉", "😘", "🤣", "😢", "😴", "🤩", "🥳",
        "👌", "💪", "🙌", "✨", "⭐", "🌈", "🎵", "💀"
    )

    private val repeatDelete = object : Runnable {
        override fun run() {
            delete()
            handler.postDelayed(this, 60)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun loadPrefs() {
        val p = getSharedPreferences("rgb", MODE_PRIVATE)
        theme = Themes.all[p.getInt("theme", 0).coerceIn(0, Themes.all.size - 1)]
        vibrate = p.getBoolean("vibrate", true)
        speed = p.getInt("speed", 5).coerceIn(1, 10)
    }

    override fun onCreateInputView(): View {
        loadPrefs()
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        build()
        return container
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (::container.isInitialized) {
            mode = Mode.LETTERS
            shift = false
            build()
        }
    }

    private fun build() {
        container.removeAllViews()
        keys.clear()
        letters.clear()
        when (mode) {
            Mode.LETTERS -> buildLetters()
            Mode.SYMBOLS -> buildSymbols()
            Mode.EMOJI -> buildEmoji()
        }
    }

    private fun newRow(): LinearLayout = LinearLayout(this).apply { gravity = Gravity.CENTER }

    private fun disp(c: Char): String = if (shift) c.uppercaseChar().toString() else c.toString()

    private fun charRow(chars: String, letter: Boolean = false): LinearLayout {
        val r = newRow()
        chars.forEach { c ->
            val label = if (letter) disp(c) else c.toString()
            r.addView(makeKey(label, 1f, letter) { s -> type(s) })
        }
        return r
    }

    private fun buildLetters() {
        container.addView(charRow("1234567890"))
        container.addView(charRow("qwertyuiop", true))
        container.addView(charRow("asdfghjkl", true))

        val r3 = newRow()
        r3.addView(makeKey("⇧", 1.5f) { toggleShift() })
        "zxcvbnm".forEach { c -> r3.addView(makeKey(disp(c), 1f, true) { s -> type(s) }) }
        r3.addView(deleteKey(1.5f))
        container.addView(r3)

        val r4 = newRow()
        r4.addView(makeKey("?123", 1.5f) { mode = Mode.SYMBOLS; build() })
        r4.addView(makeKey(",", 1f) { s -> type(s) })
        r4.addView(makeKey("😀", 1.2f) { mode = Mode.EMOJI; build() })
        r4.addView(makeKey("space", 4f) { type(" ") })
        r4.addView(makeKey(".", 1f) { s -> type(s) })
        r4.addView(makeKey("↵", 1.5f) { enter() })
        container.addView(r4)
    }

    private fun buildSymbols() {
        container.addView(charRow("1234567890"))
        container.addView(charRow("@#₹_&-+()/"))
        val r3 = newRow()
        "*\"':;!?=%".forEach { c -> r3.addView(makeKey(c.toString(), 1f) { s -> type(s) }) }
        r3.addView(deleteKey(1.5f))
        container.addView(r3)

        val r4 = newRow()
        r4.addView(makeKey("ABC", 1.5f) { mode = Mode.LETTERS; build() })
        r4.addView(makeKey(",", 1f) { s -> type(s) })
        r4.addView(makeKey("space", 4f) { type(" ") })
        r4.addView(makeKey(".", 1f) { s -> type(s) })
        r4.addView(makeKey("↵", 1.5f) { enter() })
        container.addView(r4)
    }

    private fun buildEmoji() {
        emojis.chunked(8).forEach { chunk ->
            val r = newRow()
            chunk.forEach { e -> r.addView(makeKey(e, 1f, false, 22f) { s -> type(s) }) }
            container.addView(r)
        }
        val r4 = newRow()
        r4.addView(makeKey("ABC", 2f) { mode = Mode.LETTERS; build() })
        r4.addView(makeKey("space", 4f) { type(" ") })
        r4.addView(deleteKey(2f))
        container.addView(r4)
    }

    private fun makeKey(
        label: String,
        weight: Float,
        letter: Boolean = false,
        size: Float = 18f,
        onTap: (String) -> Unit
    ): TextView {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Color.parseColor("#111111"))
            setStroke(dp(2), Color.RED)
        }
        val tv = TextView(this).apply {
            text = label
            textSize = size
            gravity = Gravity.CENTER
            background = bg
            isClickable = true
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
        }
        tv.setOnClickListener {
            haptic(tv)
            onTap(tv.text.toString())
        }
        keys.add(Key(tv, bg, keys.size))
        if (letter) letters.add(tv)
        return tv
    }

    private fun deleteKey(weight: Float): TextView {
        val tv = makeKey("⌫", weight) { }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    haptic(v)
                    delete()
                    handler.postDelayed(repeatDelete, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeatDelete)
                }
            }
            true
        }
        return tv
    }

    private fun haptic(v: View) {
        if (vibrate) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shift && mode == Mode.LETTERS) {
            shift = false
            applyShift()
        }
    }

    private fun delete() {
        val ic = currentInputConnection ?: return
        if (ic.getSelectedText(0).isNullOrEmpty()) ic.deleteSurroundingText(1, 0)
        else ic.commitText("", 1)
    }

    private fun enter() {
        if (!sendDefaultEditorAction(true)) currentInputConnection?.commitText("\n", 1)
    }

    private fun toggleShift() {
        shift = !shift
        applyShift()
    }

    private fun applyShift() {
        letters.forEach {
            val t = it.text.toString()
            it.text = if (shift) t.uppercase() else t.lowercase()
        }
    }

    private fun startRgb() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = (12000L / speed)
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { a ->
                val base = a.animatedValue as Float
                keys.forEach { k ->
                    val hue = theme.hue(base, k.index)
                    val color = Themes.color(hue)
                    k.bg.setStroke(dp(2), color)
                    k.bg.setColor(Themes.color(hue, 40))
                    k.view.setTextColor(color)
                    k.view.setShadowLayer(10f, 0f, 0f, color)
                }
            }
            start()
        }
    }

    override fun onWindowShown() {
        super.onWindowShown()
        loadPrefs()
        startRgb()
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        animator?.cancel()
        handler.removeCallbacks(repeatDelete)
    }

    override fun onDestroy() {
        animator?.cancel()
        handler.removeCallbacks(repeatDelete)
        super.onDestroy()
    }
}
