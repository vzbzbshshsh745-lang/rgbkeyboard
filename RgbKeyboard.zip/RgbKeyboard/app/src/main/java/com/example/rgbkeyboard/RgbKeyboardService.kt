package com.example.rgbkeyboard

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView

class RgbKeyboardService : InputMethodService() {

    private class Key(val view: TextView, val bg: GradientDrawable, val index: Int)

    private val keys = mutableListOf<Key>()
    private val letters = mutableListOf<TextView>()
    private var animator: ValueAnimator? = null
    private var shift = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreateInputView(): View {
        keys.clear(); letters.clear()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        root.addView(row("1234567890".map { it.toString() }))
        root.addView(row("qwertyuiop".map { it.toString() }, letters = true))
        root.addView(row("asdfghjkl".map { it.toString() }, letters = true))

        val r3 = LinearLayout(this)
        r3.addView(makeKey("⇧", 1.5f) { toggleShift() })
        "zxcvbnm".forEach { c -> r3.addView(makeKey(c.toString(), 1f, letter = true) { type(it) }) }
        r3.addView(makeKey("⌫", 1.5f) { delete() })
        root.addView(r3)

        val r4 = LinearLayout(this)
        r4.addView(makeKey(",", 1f) { type(",") })
        r4.addView(makeKey("space", 5f) { type(" ") })
        r4.addView(makeKey(".", 1f) { type(".") })
        r4.addView(makeKey("↵", 1.5f) { enter() })
        root.addView(r4)
        return root
    }

    private fun row(chars: List<String>, letters: Boolean = false): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER
        chars.forEach { c -> r.addView(makeKey(c, 1f, letter = letters) { type(it) }) }
        return r
    }

    private fun makeKey(label: String, weight: Float, letter: Boolean = false, onTap: (String) -> Unit): TextView {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Color.parseColor("#111111"))
            setStroke(dp(2), Color.RED)
        }
        val tv = TextView(this).apply {
            text = label
            textSize = 18f
            gravity = Gravity.CENTER
            background = bg
            isClickable = true
            layoutParams = LinearLayout.LayoutParams(0, dp(48), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            setOnClickListener { onTap(text.toString()) }
        }
        keys.add(Key(tv, bg, keys.size))
        if (letter) letters.add(tv)
        return tv
    }

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shift) toggleShift()
    }

    private fun delete() {
        val ic = currentInputConnection ?: return
        if (ic.getSelectedText(0).isNullOrEmpty()) ic.deleteSurroundingText(1, 0)
        else ic.commitText("", 1)
    }

    private fun enter() {
        if (!sendDefaultEditorAction(true)) currentInputConnection?.commitText("\n", 1)
    }

    private fun toggleShift() {
        shift = !shift
        letters.forEach { it.text = if (shift) it.text.toString().uppercase() else it.text.toString().lowercase() }
    }

    private fun startRgb() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 4000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { a ->
                val base = a.animatedValue as Float
                keys.forEach { k ->
                    val hue = (base + k.index * 10f) % 360f
                    val color = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
                    k.bg.setStroke(dp(2), color)
                    k.view.setTextColor(color)
                }
            }
            start()
        }
    }

    override fun onWindowShown() { super.onWindowShown(); startRgb() }
    override fun onWindowHidden() { super.onWindowHidden(); animator?.cancel() }
    override fun onDestroy() { animator?.cancel(); super.onDestroy() }
}
